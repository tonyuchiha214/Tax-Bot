// tax.js - Your bot's logic
console.log('Tax module loaded');
