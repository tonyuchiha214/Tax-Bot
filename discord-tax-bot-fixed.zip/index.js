import 'dotenv/config';
import './tax.js';

console.log('Discord Tax Bot is running...');
