// src/index.js — Bot start & command registration
import { Client, GatewayIntentBits, REST, Routes } from 'discord.js';
import { buildTaxCommands, handleTaxInteraction, initTaxScheduler } from './tax.js';
import 'dotenv/config';

const config = {
  TOKEN: process.env.BOT_TOKEN,
  CLIENT_ID: process.env.CLIENT_ID,
  GUILD_ID: process.env.GUILD_ID,
  SELLER_ROLE_ID: process.env.SELLER_ROLE_ID,
  TAX_PENDING_ROLE_ID: process.env.TAX_PENDING_ROLE_ID,
  TAX_COLLECTOR_ID: process.env.TAX_COLLECTOR_ID,
  TAX_PERCENT: parseFloat(process.env.TAX_PERCENT || '0.15'),
  TAX_GIF_URL: process.env.TAX_GIF_URL || 'https://example.com/tax.gif',
  PAYPAL_NAME: process.env.PAYPAL_NAME || 'YourPayPal',
};

['TOKEN', 'CLIENT_ID', 'GUILD_ID'].forEach(key => {
  if (!config[key]) {
    console.error(`❌ Missing required environment variable: ${key}`);
    process.exit(1);
  }
});

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.DirectMessages,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

async function registerCommands() {
  const commands = buildTaxCommands();
  const rest = new REST({ version: '10' }).setToken(config.TOKEN);
  try {
    console.log('📡 Registering slash commands...');
    await rest.put(
      Routes.applicationGuildCommands(config.CLIENT_ID, config.GUILD_ID),
      { body: commands }
    );
    console.log('✅ Slash commands registered.');
  } catch (err) {
    console.error('❌ Failed to register commands:', err);
  }
}

client.once('ready', () => {
  console.log(`🤖 Logged in as ${client.user.tag}`);
  initTaxScheduler(client, {
    TAX_GIF_URL: config.TAX_GIF_URL,
    PAYPAL_NAME: config.PAYPAL_NAME,
  });
});

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isChatInputCommand()) return;
  try {
    await handleTaxInteraction(interaction, client, config);
  } catch (err) {
    console.error('❌ Command error:', err);
    if (!interaction.replied) {
      interaction.reply({ content: 'An error occurred.', ephemeral: true });
    }
  }
});

(async () => {
  await registerCommands();
  client.login(config.TOKEN);
})();