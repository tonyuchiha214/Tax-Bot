// index.js
import { Client, GatewayIntentBits, REST, Routes } from 'discord.js';
import { buildTaxCommands, handleTaxInteraction, initTaxScheduler } from './tax.js';
import dotenv from 'dotenv';

// Load environment variables from .env
dotenv.config();

// ===== Bot Config =====
const config = {
  SELLER_ROLE_ID: process.env.SELLER_ROLE_ID,
  TAX_PENDING_ROLE_ID: process.env.TAX_PENDING_ROLE_ID,
  TAX_COLLECTOR_ID: process.env.TAX_COLLECTOR_ID,
  TAX_PERCENT: parseFloat(process.env.TAX_PERCENT || '0.1'), // 10% default
  TAX_GIF_URL: process.env.TAX_GIF_URL,
  PAYPAL_NAME: process.env.PAYPAL_NAME
};

// ===== Client Setup =====
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.DirectMessages
  ]
});

// ===== Register Slash Commands =====
async function registerCommands() {
  const commands = buildTaxCommands();
  const rest = new REST({ version: '10' }).setToken(process.env.BOT_TOKEN);

  try {
    console.log('Registering application commands...');
    await rest.put(
      Routes.applicationCommands(process.env.CLIENT_ID),
      { body: commands }
    );
    console.log('✅ Commands registered.');
  } catch (error) {
    console.error('Error registering commands:', error);
  }
}

// ===== Event: Bot Ready =====
client.once('ready', () => {
  console.log(`✅ Logged in as ${client.user.tag}`);
  initTaxScheduler(client, {
    TAX_GIF_URL: config.TAX_GIF_URL,
    PAYPAL_NAME: config.PAYPAL_NAME
  });
});

// ===== Event: Slash Command Interaction =====
client.on('interactionCreate', async interaction => {
  if (!interaction.isChatInputCommand()) return;

  try {
    await handleTaxInteraction(interaction, client, config);
  } catch (err) {
    console.error('Command error:', err);
    if (!interaction.replied) {
      interaction.reply({ content: '❌ An error occurred.', ephemeral: true });
    }
  }
});

// ===== Start Bot =====
(async () => {
  await registerCommands();
  await client.login(process.env.BOT_TOKEN);
})();